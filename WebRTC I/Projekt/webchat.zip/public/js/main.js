(function(){
	var App={};
	
	var localStream;
	App.myid=0;
	App.acceptOffer=true;
	// pc.getRemoteStreams()[0].getAudioTracks()[0]; getReadyState
	
	function User(id,name){
		this.name=name;
		this.id=id;
		this.connected=false;
		this.init=function(){
			var user=this;
			var $but=$('<button>');
			
			var $p=$('<p/>',{
				'text': user.name
			});

			var $div=$('<div/>', {
				'id': user.id,
				'class': 'remoteElem'
			});
			
			var $remoteAudio=$('<audio controls="controls" autoplay></audio>');
			this.audio=$remoteAudio;
			$but.appendTo($p);
			$p.appendTo($div);
			$remoteAudio.appendTo($div);
			$div.appendTo($remoteDiv);
			user.div=$div;
			this.setDisconnected();
		}
		
		this.send=function(type,data){
			App.sendDirect(data,type,this.id);
		}
		
		this.connect=function(){	
			this.RTC=new RTC(this,localStream,this.audio.get(0),App.logError);
			this.RTC.start();
			this.RTC.connect();
		}
				
		this.setConnected=function(){
			this.connected=true;
			this.audio.show();
			this.div.css('background-color', '#4CBB17');
			var but=$('#'+this.id+' > p >button');
			but.html('Stop');
			var user=this;
			but.unbind('click').click(function(){
				user.send('close',{});
				user.RTC.stop();
			});
		}
		
		this.setDisconnected=function(){
			this.connected=false;
			this.audio.hide();
			this.RTC=null;
			this.div.css('background-color', '#c7bc95');
			var but=$('#'+this.id+' > p >button');
			but.html('Connect');
			var user=this;
			but.unbind('click').click(function(){
				user.connect();
			});
		}
		this.init();

	};
	
	var nfield;
	var pbutton;
	var namediv;
	var $srcDiv;
	var $remoteDiv;
	var srcElem;
	var users={};
	
	App.socket=null;
	App.rtc=null;
	
	App.init=function(){
		App.socket = io.connect();
		nfield=$('#namefield').get(0);
		pbutton=$('#pbutton').get(0);
		namediv=$('#nameinput').get(0);
		srcElem=$('#srcElem').get(0);
		$srcDiv=$('#srcDiv');
		$remoteDiv=$('#remoteDiv');
		$remoteDiv.hide();
		pbutton.onclick = App.setReady;
		
		
		App.socket.on('users', function (userList){
			App.myid=App.socket.socket.sessionid;
			for( var i =0;i<userList.length;i++){
				var user=userList[i];
				if(user.id==App.myid){
					continue;
				}
				if(users[user.id]){
					users[user.id].name=user.name;
				} else{
					users[user.id]=new User(user.id,user.name);
				}
			}
			
		});
		
		App.socket.on('userleft',function (id){
			var user=users[id];
			if(user){
				if(user.connected){
					user.RTC.stop();
				}
				if(user.div){
					$('#'+id).remove();
				}
				delete users[id];
			}
		});
		
		// WebRTC
		App.socket.on('desc',function(msg){
			var user=users[msg.senderid];

			if(msg.type==='offer'){
				if(App.acceptOffer){
					if(!user.RTC){
						user.RTC=new RTC(user,localStream,user.audio.get(0),App.logError);
						user.RTC.start();
					}				
					user.RTC.receivedOffer(msg);
				}
			} else if(msg.type==='answer'){
				if(user.RTC){
					user.RTC.receivedAnswer(msg);
				} else{
					console.log('invalid state, received answer without having RTC object');
					console.log(msg);
				}
			} else {
				console.log('Received invalid description:');
				console.log(msg);
			}
		});
		
		App.socket.on('candidate',function(msg){
			var user=users[msg.senderid];
			if(msg.type==='candidate'){
				if(user.RTC){
					user.RTC.receivedCandidate(msg);
				} else{
					console.log('received candidate without a RTC object');
				}
			} else {
				console.log('Received invalid candidate:');
				console.log(msg);
			}
		});
		
		App.socket.on('close',function(msg){
			var user=users[msg.senderid];
			if(user.connected){
				user.RTC.stop();
			}
		});
		
		App.socket.on('pvt',function(msg){
			console.log('pvt msg from: '+msg.senderid);
			console.log(msg);
		});
		
		App.initMedia();

	}
	
	App.sendDirect=function(data,type,id){
		cont={};
		cont.data=data;
		cont.uid=id;
		cont.evtType=type;
		App.socket.emit('direct',cont);
	}
	
	
	App.initMedia=function(){
		getUserMedia({ "audio": true }, function (stream) {
			localStream=stream;
			var srcAudio=$('<audio controls="controls" autoplay muted></audio>');
			srcAudio.attr('src',URL.createObjectURL(stream));
			$srcDiv.append(srcAudio);
		}, function(error){
			alert('Access to audio source failed: '+error.name);
			App.logError(error);
		});
	}
		

	
	
	App.setReady=function() {
		var name=nfield.value;
		if (name !== "") {
			$remoteDiv.show();
			App.socket.emit('ready', name);
			namediv.innerHTML="Name: "+name;

			var $but=$('<button>',{
				text: 'Connect to all',
				click: function(){
					for(var u in users){
						if(!users[u].connected){
							users[u].connect();
						}
					}
				}
			});
			var $remoteHeader=$('<div>');

			var $span=$('<span>',{
				text: 'Accept offers:'
			});
			
			var $checkbox=$('<input type="checkbox" />');
			$checkbox.change(function(){
				App.acceptOffer=this.checked;
			});
			
			$span.append($checkbox);
		
			$remoteHeader.append($but);
			$remoteHeader.append($span);
			
			$remoteDiv.prepend($remoteHeader);
			$checkbox.attr('checked', true);
		}
	}
	
	App.logError=function(error) {
		console.log(error.name + ": " + error.message);
		console.error(error);
	}

	
	$(document).ready( function(){
		App.init();
	});
}).call(this);