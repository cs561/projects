var static = require('node-static');
var http = require('http');
var clients = require("./Clients")();
var file = new(static.Server)(__dirname+'/public');
var app = http.createServer(function (req, res) {
  file.serve(req, res);
}).listen(2013);

var io = require('socket.io').listen(app);

io.sockets.on('connection', function (socket){
		clients.set(socket,{name: ""});
		
		function addUser(name){
			clients.setName(socket,name);
			sendUsers();
		}

		function removeUser(){
			clients.remove(socket);
			sendUsers();
			io.sockets.emit('userleft',socket.id);
		}
		
		function sendUsers(){
			var cls=clients.getUsers();
			io.sockets.emit('users',cls);
		}
		
		sendUsers();

        socket.on('ready', function (name) {
                console.log('Got user name:', name);
				addUser(name);
        });

		
		socket.on('disconnect', function(){
			console.log("DISCONNECT");
			removeUser();
		});
        
		socket.on('send',function(evt){
			console.log('received send');
			socket.broadcast.emit('onmessage',evt);
		});
		
		socket.on('direct',function(evt){
			var cli=clients.getById(evt.uid);
			if(cli && cli.socket){
				if(typeof evt.data==='object'){
					evt.data.senderid=socket.id;
				}
				cli.socket.emit(evt.evtType,evt.data);
			}
			//io.sockets.socket(evt.uid).emit(evt.evtType,evt.data); // security? maybe offer some evtTypes and then use switch
		});
		
});
