var RTC=function(u,srcStr,remoteElem,logError){
	//var configuration = {"iceServers": []};
	//var configuration = {"iceServers": [{"url": "stun:stun.stunprotocol.org"}]};
	//var configuration = {"iceServers": [{"url": "stun:stun.l.google.com:19302"}]};
	
	var configuration = { "iceServers": [{ "url": "stun:23.21.150.121" }] };
	//var configuration = { "iceServers": [{ "url": "stun:stun.example.org" }] };
	var mediaConstraints = {'mandatory': {
        'OfferToReceiveAudio': true}};
	
	var MYRTC=this;
	var pc;
	var srcStream=srcStr;
	var user=u;

	
	this.start=function() {
		console.log('start');
		
		if (navigator.webkitGetUserMedia) {
			pc=new RTCPeerConnection(configuration, {
				optional: [{
						DtlsSrtpKeyAgreement: true
					}
				]
			});
		} else{
			pc=new RTCPeerConnection(configuration);
		}
		document.pc=pc;
		console.log(pc);
		pc.addStream(srcStream);
		
		// send any ice candidates to the other peer
		pc.onicecandidate = function (evt) {
			if (evt.candidate){
				console.log(evt.candidate);
				var candidate={type: 'candidate',
					sdpMLineIndex: evt.candidate.sdpMLineIndex,
					candidate: evt.candidate.candidate};
				user.send('candidate',candidate);
				console.log('candidate sent');
			} else{
				console.log("End of candidates.");
			}
		};

		this.connect=function(){
			pc.createOffer(localDescCreated, logError,mediaConstraints);
			console.log('created Offer');
		}
		
		// once remote stream arrives, show it in the remote audio element
		pc.onaddstream = function (evt) {
			console.log('Remote stream added');
			remoteElem.src = URL.createObjectURL(evt.stream);
		};
		
		pc.onremovestream=function(evt){
			console.log("Remote stream was removed");
			remoteElem.src="";
			remoteElem.remove();
		}

		pc.oniceconnectionstatechange=function(){
			console.log(pc.iceConnectionState);
			if(pc.iceConnectionState === 'closed'){
				user.setDisconnected();
			} else if(pc.iceConnectionState === 'connected'){
				user.setConnected();
			}
		}
		
	}

	this.stop=function(){
		console.log('Closed PeerConnection');
		pc.close();
	}
	
	function localDescCreated(desc) {
		// alter desc, try different codecs
		//console.log(desc.sdp);
		//outList=['opus','PCMU','telephone'];
		//desc.sdp=filterSDP(desc.sdp,outList,'PCMA');
		
		//outList=['opus','PCMA','telephone'];
		//desc.sdp=filterSDP(desc.sdp,outList,'PCMU');
		
		//outList=['PCMA','PCMU','telephone'];
		//desc.sdp=filterSDP(desc.sdp,outList,'opus');
		
		console.log(desc.sdp);
		pc.setLocalDescription(desc, function () {
			user.send('desc',desc);
			console.log('emitted localDescription');
			console.log(desc);
		}, logError);
	}

	this.receivedOffer=function(offer){
		console.log('setRemoteDescription');
		var remoteDesc=new RTCSessionDescription(offer);
		console.log(remoteDesc);
		pc.setRemoteDescription(remoteDesc,function(){
			console.log('Sending answer...');
			pc.createAnswer(localDescCreated, logError,{'mandatory': { 'OfferToReceiveAudio':true}});
		});
	}
	
	this.receivedAnswer=function(answer){
		console.log('setRemoteDescription');
		var remoteDesc=new RTCSessionDescription(answer);
		console.log(remoteDesc);
		pc.setRemoteDescription(remoteDesc);
	}
	
	this.receivedCandidate=function(candidate){
		var candidate = new RTCIceCandidate(candidate);
		console.log(candidate);
		pc.addIceCandidate(candidate);
	}

}