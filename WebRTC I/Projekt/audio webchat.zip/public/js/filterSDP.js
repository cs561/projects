// TODO:
//	-include in project
//	-refactor finding of protocol number into a function
//	-remove from global scope

// filterOut is list of strings of Protocol names, left is string protocol name
filterSDP=function(sdp,filterOut,left){
	// first we get the protocol numbers
	var outNumList=[];
	for(var i in filterOut){
		var ss='(a=rtpmap:)(\\d*)(\.'+filterOut[i]+')';
		var pat=new RegExp(ss);
		var temp=sdp.match(pat);
		if(temp==null){	// no match, nothing to do
			continue;
		}
		temp=temp[0];
		temp=temp.match(/(\d)(\d*)/)[0];
		outNumList.push(temp);
		
		// also removing the complete a=rtpmap line
		ss=ss+'(.*?)(\\r\\n)';
		pat=new RegExp(ss,'g');
		sdp=sdp.replace(pat,'');		
	}
	
	console.log(outNumList);
	
	// get number of left
	ss='(a=rtpmap:)(\\d*)(\.'+left+')';
	var pat=new RegExp(ss);
	var leftNr=sdp.match(pat)[0];
	leftNr=leftNr.match(/(\d)(\d*)/)[0];
	
	// now remove codecs from m line, we replace the line
	
	sdp=sdp.replace(/(m=audio.)(\d*)(.RTP\/SAVPF)(.\d)*/,'m=audio 59263 RTP/SAVPF '+leftNr);
	
	return sdp;
}

// Test call:
var SDP= ["v=0"
    ,"o=Mozilla-SIPUA-25.0.1 6034 0 IN IP4 0.0.0.0"
    ,"m=audio 59263 RTP/SAVPF 109 0 8 101"
    ,"c=IN IP4 87.102.133.31"
    ,"a=rtpmap:109 opus/48000/2"
    ,"a=ptime:20"
    ,"a=rtpmap:0 PCMU/8000"
    ,"a=rtpmap:8 PCMA/8000"
    ,"a=rtpmap:101 telephone-event/8000"
    ,"a=fmtp:101 0-15",
    ""
].join("\r\n");

//outList=['PCMU','opus','telephone'];

//filterSDP(SDP,outList,'PCMA')
