var Clients= new function(){
	this._clients={};
	
	this.set=function(client,data){
		data.id=client.id;
		data.socket=client;
		this._clients[client.id]=data;
	};
	
	this.get=function(client){
		return this._clients[client.id];
	}
	
	this.getById=function(id){
		return this._clients[id];
	}
	this.setName=function(client,name){
		this._clients[client.id].name=name;
	}
	
	this.remove=function(client){
		delete this._clients[client.id];
	}
	
	this.getUsers=function(){
		var users=[];
		for(var prop in this._clients){
			if(this._clients.hasOwnProperty(prop)){
				var data=this._clients[prop];
				if (data.hasOwnProperty('name') && data.name!="" && data.hasOwnProperty('id')){
					users.push({name: data.name, id: data.id});
				}
			}
		}
		return users;
	}
	
};

module.exports=function(){
	return Object.create(Clients);
};