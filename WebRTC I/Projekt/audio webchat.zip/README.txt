nodejs plugins (mit npm installieren):
socket.io
node-static

Je nachdem weitere fehlende Packages selber installieren. (Raspberry Pi ben�tigte noch: bcrypt und zeparser)

server.js mit nodejs starten (Client.js ist Datenstruktur f�r die Userverwaltung)
Server l�uft auf Port 2013


filterSDP can be called in the function localDescCreated in RTC.js (line 81)



Contact: c.betschart@stud.unibas.ch