To sue this, please download reveal.js and place the contents of this archive in the root folder of the reveal.js folder

download link:
https://github.com/hakimel/reveal.js#installation
